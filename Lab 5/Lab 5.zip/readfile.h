#include <string>
#include <fstream>
#include <iostream>
#ifndef READFILE_H
#define READFILE_H
using namespace std;

//PUT YOUR FUNCTION PROTOTYPE HERE
void readFiletoArray(string filename, int* data);

#endif