#ifndef MODE_H
#define MODE_H

//PUT YOUR FUNCTION PROTOTYPE HERE
void findModes(int input[], int size, int& frequency, int result[], int& result_count);

#endif