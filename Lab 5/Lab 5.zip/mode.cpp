#include <string>
#include <fstream>
#include <iostream>
#include "readfile.h"
using namespace std;

//IMPLEMENT YOUR FUNCTION HERE
void findModes(int input[], int size, int& frequency, int result[], int& result_count){
    // int currVal;
    // for (int i = 0; i < size; i++)
    // {
    //     if ()
    //     {
    //         result[]
    //     }
    //     else{
    //         currVal = input[i];
    //     }
    
        
    // }
}